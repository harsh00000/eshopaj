from django import template
register = template.Library()
from foodapp.models import *

@register.filter(name='is_in_cart')
def cart(dishes, cart):


    try:
        keys = cart.keys()
        for id in keys:
            if int(id) == dishes:
                return True
    except:
        return False


@register.filter(name='cart_qty')
def cart_qty(dishes, cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == dishes:
            return cart.get(id)
    return 0


@register.filter(name='total_price')
def total_price(id, cart):
    return id.price * cart_qty(id.id, cart)


@register.filter(name='subtotal')
def subtotal(id, cart):
    sum = 0
    for p in id:
        sum += (total_price(p, cart))

    return sum

@register.filter(name='total')
def total(id, cart):
    sum = 0
    for p in id:
        sum += (total_price(p, cart))
    sum += 30
    return sum

@register.filter
def get_item(val):

    res = Restaurant.objects.filter(rname=val)
    # men = Menuitem.objects.filter(name=val)
    # print('men:',men)
    return (res)

@register.filter
def items(val):
    print(val)


@register.filter
def item(value):
    if isinstance(value,list):
        return True
    else:
        return False
