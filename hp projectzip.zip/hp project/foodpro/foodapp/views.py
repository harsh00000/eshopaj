from django.shortcuts import render , HttpResponseRedirect , redirect , HttpResponse
from .models import *
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.datastructures import MultiValueDictKeyError
import requests, random
from .forms import *
from .PayTm import Checksum
import hashlib
import json
from django.core.files.storage import FileSystemStorage
MERCHANT_KEY = 'P88e0bC8zLGHXH9t'
# Create your views here.
def index(request):
    if request.method == 'POST':
        pass
    else:

        filterLh = request.GET.get('cost_for_two')
        dfilterLh = request.GET.get('Delivery_Time')
        if filterLh:
            restaurat = Restaurant.objects.order_by('cost_for_two')
        elif dfilterLh:
            restaurat = Restaurant.objects.order_by('deliverytime')
        else:
            restaurat = Restaurant.objects.all()
        count = Restaurant.objects.filter(approved=True).count()
        user = request.session.get('customer')

        cst=""
        crestaurat=""
        item=""
        try:
            cst = Customer.objects.get(id=user)
        except Customer.DoesNotExist:
            print('no')
        try:
            cart = request.session.get("cart")
            if cart:
                lst = (list(request.session.get("cart").keys()))
                item = Menuitem.get_item(lst)
            else:
                request.session['cart']={}
            res = request.session.get("res")
            crestaurat = Restaurant.objects.get(id=res)

        except :
            item = {}
        vks = Menuitem.objects.all()
        context = {
            'restaurat':restaurat,
            'customer':cst,
            'items':item,
            'crestaurant':crestaurat,
            'count':count,
            'cart':cart,
            'slider':vks
        }

        return render(request, 'quickmain.html',context)

@csrf_exempt
def search(request):
    if 'restsubmit' in request.POST:
        rest = ""
        name =request.POST.get("restname")
        if name:
            rest = Restaurant.objects.filter(rname__icontains=name)
            print(rest)
        else:
            print("no rest")

        return render(request,'searchpage.html',{'restaurant':rest})
    elif 'itemsubmit' in request.POST:
        vs=[]
        dicts={}
        searchq = request.POST.get("itemname")
        print(searchq)
        if searchq:
            dish = Menuitem.objects.filter(name__icontains=searchq)
            for a in dish:
                vs.append(a.catagory.restaurant)
                set_key(dicts,a.catagory.restaurant,a)
            print(dicts)
        return render(request,'searchpage.html',{'dicts':dicts})
    elif 'cartsubmit' in request.POST:
        print("hi")
    else:
        crestaurat=""
        try:
            res = request.session.get("res")
            crestaurat = Restaurant.objects.get(id=res)
        except Restaurant.DoesNotExist:
            pass
        cart = request.session.get("cart")
        item=""
        if cart:
            lst = (list(request.session.get("cart").keys()))
            item = Menuitem.get_item(lst)
        else:
            request.session['cart']={}
        try:
            lst = (list(request.session.get("cart").keys()))
            items = Menuitem.get_item(lst)

        except:
            items = {}
        user = request.session.get('customer')
        cst = ""
        try:
            cst = Customer.objects.get(id=user)
        except Customer.DoesNotExist:
            print("")

        return render(request,'searchpage.html',{'item':items,'cart':cart,'crestaurant':crestaurat,'items':item,'customer':cst})

def UserCreate(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        phone = request.POST.get("phone")
        email = request.POST.get("email")
        otp = request.POST.get("otp")
        votp = request.session.get("otp")
        #votp = 500
        exist=""
        try:
            exist = Customer.objects.get(phone_number=phone)
        except Customer.DoesNotExist:
            print('no found')
        if not exist:
            if votp == int(otp):
                request.session.pop("otp")
                customer = Customer(name=name,phone_number=phone,email=email)
                customer.save()
                request.session['customer']=customer.id
                print(customer.id)
                print('sucessfully')
            else:
                print("not match")

        return JsonResponse({'status':1})
    else:
        return JsonResponse({'status':0})

def UserLogin(request):
    if request.method == "POST":
        phone = request.POST.get("phone")
        otp = request.POST.get("otp")
        #votp = request.session.get("otp")
        votp=500
        customer=""
        if votp == int(otp):
            #request.session.pop("otp")
            try:
                customer = Customer.objects.get(phone_number=phone)
                request.session['customer']=customer.id
            except Customer.DoesNotExist:
               print("no match")

        else:
            print("not match")

        return JsonResponse({'status':1})
    else:
        return JsonResponse({'status':0})

def userprofile(request):
    if 'editadd' in request.POST:
        adid = request.POST.get("adid")
        name = request.POST.get("name")
        address = request.POST.get("address")
        landmark = request.POST.get("landmark")
        pincode = request.POST.get("pincode")
        city = request.POST.get("city")
        state = request.POST.get("state")
        CustomerAddress.objects.filter(id=adid).update(name=name,address=address,landmark=landmark,pincode=pincode,city=city,state=state)
        return redirect('userprofile')
    else:
        user = request.session.get('customer')
        if user:
            customer = Customer.objects.get(id=user)
            crestaurat=""
            cst=""
            favourite = []
            v=[]
            v.append(OrderTrack.objects.filter(orderedBy=user).order_by('-timestamp'))
            # for s in v:
            #     for i in s:
            #         print(i)
            #         vk = i.order.all()
            #         for sks in vk:
            #             print(sks.r_id.rname)
            #             break
            for i in Restaurant.objects.all():
                if customer in i.favourite.all()  :
                    favourite.append(i)

            address = CustomerAddress.objects.filter(customer=user)
            try:
                cst = Customer.objects.get(id=user)
            except Customer.DoesNotExist:
                print("")
            try:
                res = request.session.get("res")
                crestaurat = Restaurant.objects.get(id=res)
            except Restaurant.DoesNotExist:
                print("")
            cart = request.session.get('cart')
            item={}
            if cart:
                lst = (list(request.session.get("cart").keys()))
                item = Menuitem.get_item(lst)
            else:
                request.session['cart']={}
            context = {
                'crestaurant':crestaurat,
                'customer':cst,
                'order':v,
                'address':address,
                'cart':cart,
                'items':item,
                'favourite':favourite,
            }
            return render(request, 'userprofile.html',context)
        else:
            return redirect('index')

def SendOtp(request):
    if request.method == 'POST' and  request.is_ajax():
        number = request.POST.get('MobNumber')
        print(number)
        otp = random.randrange(00000, 99999)
        url = "https://www.fast2sms.com/dev/bulk"

        querystring = {
            "authorization": "k0nSzF5sEJtU8GY1gem7ZNr4Mc3OuVLXCphwoWqaTvfAKdy9xP1VfQZ0N2rsh3G8kt9KToBDPUM4yvie",
            "sender_id": "FSTSMS", "language": "english", "route": "qt", "numbers": number, "message": "37622",
            "variables": "{AA}", "variables_values": otp}

        headers = {
            'cache-control': "no-cache"
        }

        response = requests.request("GET", url, headers=headers, params=querystring)

        print(response.text)
        otp = request.session["otp"] = otp
        print(otp)
        return JsonResponse({"status": 1})
    else:
        return JsonResponse({"status": 0})

def Resturant(request,id):

    if request.method == 'POST':
        item = request.POST.get("item")
        remove = request.POST.get("remove")
        cart = request.session.get("cart")
        res = request.session.get('res')
        ids= id
        error = ""
        if res == id or res == None:
            if cart:
                    qty = cart.get(item)
                    if qty:
                        if remove:
                            if qty <= 1:
                                cart.pop(item)
                                try:
                                    del request.session['res']
                                except KeyError:
                                    print('done')
                            else:
                                cart[item] = qty - 1
                        else:
                            cart[item] = qty + 1
                    else:
                        cart[item] = 1
            else:
                cart = {}
                cart[item] = 1
                request.session['res']=ids
                print(request.session.get('res'))
        else:
            error = "to add this restaurant item plese clear your cart"
            return redirect(request.path)


        request.session["cart"] = cart
        print('cart>', request.session["cart"])

        return redirect(request.path)

    else:

        print(request.session.get('res'))
        cart = request.session.get("cart")
        if not cart:
            request.session['cart'] = cart
        else:
            print(request.session.get("cart").keys())

        catagorys = Catagory.objects.filter(restaurant=id)

        try:
            lst = (list(request.session.get("cart").keys()))
            item = Menuitem.get_item(lst)
        except:
            item = {}
        try:
            res = request.session.get("res")
            crestaurat = Restaurant.objects.get(id=res)
        except Restaurant.DoesNotExist:
            print("")
        rest = ''
        crestaurat=""
        try:
            rest = Restaurant.objects.get(id=id)
            res = request.session.get("res")
            crestaurat = Restaurant.objects.get(id=res)
        except Restaurant.DoesNotExist:
            print('ot exist')
        users = request.session.get('customer')

        user=""
        if users:
            user = Customer.objects.get(id=users)
            Fav = ''
            if user in rest.favourite.all():
                Fav  = True
            else:
                Fav = False
        else:
            Fav = ''


        return render(request, 'Resturant.html',{'restaurant':rest,'catagory':catagorys,'items':item,'cart':cart,'crestaurant':crestaurat,'Fav':Fav,'customer':user})

def checkout(request):
    if request.method == 'POST':
        if 'submit' in request.POST:
            # address = CustomerAddress.objects.get(id=9)

            cuaddress = request.session.get("address")
            address = CustomerAddress.objects.get(id=cuaddress)
            customer = request.session.get("customer")
            cart = request.session.get('cart')
            rest = request.session.get("res")
            res = Restaurant.objects.get(id=rest)
            items = Menuitem.get_item(list(cart.keys()))
            print( customer, cart, items)
            jobs=[]
            total = []
            for item in items:
                ord = OrderdItem( item=item,
                                  qty=cart.get(str(item.id)),
                                  )
                ord.save()
                jobs.append(ord.id)

                total.append(item.price * cart.get(str(item.id)))
            amts = sum(total) + 30
            ord = OrderTrack.objects.create(r_id=Restaurant(id=res.id),orderedBy=Customer(id=customer),total_amount=amts,delivery_addr=address)
            ord.order.add(*jobs)

            url = 'http://127.0.0.1:8000/handlerequest/'
            param_dict = {
                'MID': 'JibWRt06131456085430',
                'ORDER_ID': str(ord.order_id),
                'TXN_AMOUNT': str(amts),
                'CUST_ID': str(customer),
                'INDUSTRY_TYPE_ID': 'Retail',
                'WEBSITE': 'WEBSTAGING',
                'CHANNEL_ID': 'WEB',
                'CALLBACK_URL': url,
            }
            param_dict['CHECKSUMHASH'] = Checksum.generate_checksum(param_dict, MERCHANT_KEY)

            return render(request, 'paytm.html', {'param_dict': param_dict})

        elif 'cartsubmit' in request.POST:
            print('cart submit')
            item = request.POST.get("item")
            remove = request.POST.get("remove")
            cart = request.session.get("cart")
            if cart:
                qty = cart.get(item)
                if qty:
                    if remove:

                        if qty <= 1:
                            cart.pop(item)
                            try:
                                del request.session['res']
                            except KeyError:
                                print('done')
                        else:
                            cart[item] = qty - 1
                    else:
                        cart[item] = qty + 1
                else:
                    cart[item] = 1
            else:
                cart = {}
                cart[item] = 1
            request.session["cart"] = cart

            return redirect('checkout')
        elif 'addaddress' in request.POST:
            customer = request.POST.get("customer")
            name = request.POST.get("name")
            address = request.POST.get("address")
            landmark = request.POST.get("landmark")
            pincode = request.POST.get("pincode")
            city = request.POST.get("city")
            state = request.POST.get("state")
            CustomerAddress.objects.create(customer=Customer(id=customer),name=name,address=address,landmark=landmark,pincode=pincode,city=city,state=state)
            return redirect('checkout')
        return JsonResponse({'status':1})

    else:

        res = request.session.get('res')
        restaurant=""
        try:
            restaurant = Restaurant.objects.get(id=res)
        except Restaurant.DoesNotExist:
            print("no")
        us= request.session.get('customer')
        if not us:
            return redirect('index')
        address = CustomerAddress.objects.filter(customer=us)
        user = Customer.objects.get(id=us)
        cart = request.session.get('cart')
        try:
            lst = (list(request.session.get("cart").keys()))
            items = Menuitem.get_item(lst)

        except:
            items = {}
        return render(request, 'checkout.html', {"cart":cart,"item": items,"customer":user,'address':address,'restaurant':restaurant})

def address(request):
    if request.method == 'POST':
        addre = request.POST.get("address")
        print('addre',addre)
        address = CustomerAddress.objects.get(id=addre)
        request.session['address']=address.id
        print('cuaddress:',request.session.get("address"))
        return JsonResponse({'status':1})

@csrf_exempt
def handlerequest(request):
    form = request.POST
    response_dict = {}
    for i in form.keys():
        response_dict[i] = form[i]
        if i == 'CHECKSUMHASH':
            checksum = form[i]
    verify = Checksum.verify_checksum(response_dict, MERCHANT_KEY, checksum)
    if verify:
        if response_dict['RESPCODE'] == '01':
            request.session["cart"] = None
            oid = response_dict['ORDERID']
            print(oid)
            OrderTrack.objects.filter(order_id=oid).update(payment=True)
            return render(request, 'paytmstatus.html', {'response': response_dict})

        else:
            print('order was not successful because' + response_dict['RESPMSG'])
    return render(request, 'paytmstatus.html', {'response': response_dict})

def track(request,order_id):
    od = OrderTrack.objects.filter(order_id=order_id).first()
    address = od.delivery_addr.address
    landmark = od.delivery_addr.landmark
    pincode = od.delivery_addr.pincode
    city = od.delivery_addr.city
    state = od.delivery_addr.state
    name = od.delivery_addr.name
    rname = od.r_id.rname
    area = od.r_id.area
    vk  = od.order.all()
    qty={}
    itname={}
    itprice={}
    count = 0
    for i in vk:

        count +=1
        set_key(qty,i.id,i.qty)
        set_key(itname,i.id,i.item.name)
        price = i.qty * i.item.price
        set_key(itprice,i.id,price)

    context = {
        'order':od,
        'address':address,
        'landmark':landmark,
        'pincode':pincode,
        'city':city,
        'state':state,
        'name':name,
        'rname':rname,
        'area':area,
        'itname':itname,
        'itqty':qty,
        'itprice':itprice,
        'count':count,
        }
    return render(request,'track.html',context)


 # ------------------------------------ ----------------admin side ------------------------------------------------------

def res_login(request):
    if 'submit' in request.POST:
        phone = request.POST.get("phone")
        email = request.POST.get("email")
        otp = request.POST.get("otp")
        password = request.POST.get("password")
        votp = request.session.get("otp")
        print(votp)
        if Resuser.objects.filter(phone=phone).exists() or Resuser.objects.filter(email=email).exists() :
            print("user exist")
        else:
            if votp == int(otp) :
                pas = hashlib.md5(password.encode())
                resuser = Resuser(phone=phone,email=email,password=pas.hexdigest())
                resuser.save()
                request.session['restaurant']=resuser.id
                print(request.session.get('restaurant'))
                resuser.save()
                return redirect('res_profile')
    elif 'login' in request.POST:
        phone = request.POST.get("phone")

        password = request.POST.get("password")

        if Resuser.objects.filter(phone=phone).exists():
            resuser = Resuser.objects.get(phone=phone)
            pas = hashlib.md5(password.encode())
            print(resuser,pas)
            if resuser.password == pas.hexdigest():
                ids = resuser.id
                request.session['restaurant']=resuser.id
                ak=None
                try:
                    ak = Restaurant.objects.get(resuser=ids)

                except:
                    print("no")
                if ak:
                    if ak.approved==True:
                        return redirect('adminhome')
                    else:
                        return redirect('res_login')
                else:
                    return redirect('res_profile')
        else:
            print("wrong username")

    return render(request,'res_login.html')

def res_profile(request):
    if request.method == 'POST' and request.FILES['image']:
        res  =request.session.get("restaurant")
        if res:
            rname = request.POST.get("rname")
            owner_name = request.POST.get("owner_name")
            owner_phone = request.POST.get("owner_phone")
            address = request.POST.get("address")
            area = request.POST.get("area")
            city = request.POST.get("city")
            state = request.POST.get("state")
            files = request.FILES['image']
            fs = FileSystemStorage()
            filename = fs.save(files.name,files)
            cost_for_two = request.POST.get("cost_for_two")
            status = request.POST.get("status")
            Restaurant.objects.create(resuser=Resuser(id=res),rname=rname,owner_name=owner_name,owner_phone=owner_phone,address=address,area=area,city=city,state=state,r_logo=filename,cost_for_two=cost_for_two,status=status)
            return render(request,'res_login.html',{'sucess':'your request submitting sucessfully we ctact you soon'})
        else:
            return redirect('res_login')

    else:
        res  =request.session.get("restaurant")
        return render(request,'res_profile.html')

def adminhome(request):
    form = menu(request.POST or None, request.FILES or None)
    if 'itemcreate' in request.POST:
        if form.is_valid():
            name = form.cleaned_data['name']
            image = form.cleaned_data['image']
            veg = form.cleaned_data['veg']
            description = form.cleaned_data['description']
            price = form.cleaned_data['price']
            cat = request.POST.get("catid")
            catagory = Catagory.objects.get(id=cat)

            item = Menuitem(catagory=catagory,name=name,image=image,veg=veg,description=description,price=price)
            item.save()
            return redirect('adminhome')
    elif 'update' in request.POST:
        itemid  = request.POST.get("id")
        name  = request.POST.get("Itemname")
        veg  = request.POST.get("veg")
        desc  = request.POST.get("desc")
        price  = request.POST.get("price")

        files = request.FILES['image'] if 'image' in request.FILES else False
        if files:
            files = request.FILES['image']
            fs = FileSystemStorage()
            filename = fs.save(files.name,files)
            items = Menuitem.objects.filter(id=itemid).update(name=name,image=filename,veg=veg,description=desc,price=price)
            try:
                items.save()
            except:
                print("save")
        items = Menuitem.objects.filter(id=itemid).update(name=name,veg=veg,description=desc,price=price)
        try:
            items.save()
        except:
            print("save")
        return redirect('adminhome')
    elif 'addcatagory' in request.POST:
        resta = request.session.get("restaurant")
        restaurant = Restaurant.objects.get(resuser=resta)
        name = request.POST.get("name")
        rest = Restaurant.objects.get(id=restaurant.id)
        cat = Catagory(name=name,restaurant=rest)
        cat.save()
        return redirect('adminhome')
    elif 'profileupdate' in request.POST:
        resid  =request.POST.get('resid')
        rname  =request.POST.get('rname')
        owner_name  =request.POST.get('owner_name')
        owner_phone  =request.POST.get('owner_phone')
        address  =request.POST.get('address')
        area  =request.POST.get('area')
        city  =request.POST.get('city')
        state  =request.POST.get('state')

        try:
            files = request.FILES['image']
            fs = FileSystemStorage()
            image = fs.save(files.name,files)
            resp = Restaurant.objects.filter(id=resid).update(r_logo=image)
            try:
                resp.save()
            except:
                print("")
        except MultiValueDictKeyError:
            files = False
        cost_for_two  =request.POST.get('cost_for_two')
        deliverytime  =request.POST.get('deliverytime')
        status  =request.POST.get('status')

        resprofile = Restaurant.objects.filter(id=resid).update(rname=rname,owner_name=owner_name,owner_phone=owner_phone,address=address,area=area,city=city,state=state,cost_for_two=cost_for_two,deliverytime=deliverytime,status=status)
        try:
            resprofile.save()
        except:
            pass
        return redirect(request.path)
    elif 'reject' in request.POST:
        id = request.POST.get("orderid")
        ord = OrderTrack.objects.get(id=id)
        ord.orderconfirm = False
        ord.save()
        return redirect('adminhome')
    elif 'confirm' in request.POST:
        id = request.POST.get("orderid")
        ord = OrderTrack.objects.get(id=id)
        ord.orderconfirm = True
        ord.save()
        return redirect('adminhome')
    else:
        orderdict={}
        resta = request.session.get("restaurant")
        if not resta:
            return redirect('res_login')

        restaurant = Restaurant.objects.get(resuser=resta)
        rest = Restaurant.objects.get(id=restaurant.id)
        # restaurant order:
        order = OrderTrack.objects.filter(r_id=rest)
        for i in order:
            s = i.order.all()
            for j in s:
                set_key(orderdict,i,j)

        catagory = Catagory.objects.filter(restaurant=rest)
        catcount = Catagory.objects.filter(restaurant=rest).count()
        item=''
        if catagory:
            for cat in catagory:
                item = Menuitem.objects.filter(catagory=cat)

        context = {
            'catagory':catagory,
            'catcount':catcount,
            'item':item,
            'form':form,
            'restaurant':rest,
            'order':orderdict
        }
        return render(request,'admin.html',context)

@csrf_exempt
def statuschanges(request):
    if request.method == 'POST':
        status = request.POST.get("status")
        print(status)
        id = request.POST.get("id")
        print(id)
        ord = OrderTrack.objects.get(id=id)
        ord.status = status
        ord.save()
        return JsonResponse({'status':1})

@csrf_exempt
def changes(request):
    if request.method == 'POST':
        ids = request.POST.get("ids")

        if ids:
            menu = Menuitem.objects.filter(catagory=ids).values()
            m = list(menu)
            itemcount = 0
            for s in menu:
                itemcount += 1
            itc = [itemcount]
            return JsonResponse({'status':1,'user':m,'itemcount':itc})

    else:
        return JsonResponse({'status':0})

@csrf_exempt
def avchanges(request):
    if request.method == 'POST':
        ids = request.POST.get("avid")
        if ids:
            menu = Menuitem.objects.filter(catagory=ids).values()
            m = list(menu)
            itemcount = 0
            for s in menu:
                itemcount += 1
            itc = [itemcount]
            print(itc)
            return JsonResponse({'status':1,'avuser':m,'itemcount':itc})

    else:
        return JsonResponse({'status':0})

@csrf_exempt
def catavilable(request):
    if request.method == "POST":
        catid = request.POST.get("catid")
        cat = Catagory.objects.get(id=catid)
        val = request.POST.get("val")
        if val == 'true':
            cat.available = True
            cat.save()
        elif val == 'false':
            cat.available = False
            cat.save()
        return JsonResponse({'status':1})

@csrf_exempt
def itemavilable(request):
    if request.method == "POST":
        catid = request.POST.get("catid")
        cat = Menuitem.objects.get(id=catid)
        val = request.POST.get("val")
        if val == 'true':
            cat.available = True
            cat.save()
        elif val == 'false':
            cat.available = False
            cat.save()
        return JsonResponse({'status':1})

@csrf_exempt
def itemchanges(request):
    if request.method == 'POST':
        item_id = request.POST.get("id")
        print(item_id)
        menu = Menuitem.objects.get(id=item_id)
        dic = [{'id':menu.id,'name':menu.name,'price':menu.price,'veg':menu.veg,'desc':menu.description,'image':str(menu.image)}]
        print(dic)

        return JsonResponse({'status':1,'user':dic})

    else:
        return JsonResponse({'status':0})

@csrf_exempt
def itemdelete(request):
    if request.method=='POST':
        id = request.POST.get("sid")
        print('sid:',id)
        item = Menuitem.objects.get(id=id)
        item.delete()
        return JsonResponse({'status':1})
    else:
        return JsonResponse({'status':0})

@csrf_exempt
def trial(request):
    # if request.method == 'POST':
    #     status = request.POST.get("status")
    #     ord = OrderTrack.objects.get(id=50)
    #     ord.status = status
    #     ord.save()
    #     print('',ord.status)
    #     return render(request,'trial.html')
    if 'confirm' in request.POST:
        if request.method == 'POST':
            ids = request.POST.get("ids")
            akm = OrderTrack.objects.get(id=ids)
            akm.orderconfirm = True
            akm.save()
            return redirect(request.path)
    elif 'cancel' in request.POST:
        if request.method == 'POST':
            ids = request.POST.get("ids")
            akm = OrderTrack.objects.get(id=ids)
            akm.orderconfirm = False
            akm.save()
            return redirect(request.path)
        return render(request,'trial.html')
    else:

        # resta = request.session.get("restaurant")
        # restaurant = Restaurant.objects.get(resuser=resta)
        itemname=[]
        itemprice=[]
        itemqty=[]
        orderdict={}
        rests = Restaurant.objects.get(id=1)
        rest = Restaurant.objects.filter(id=1)

        order = OrderTrack.objects.filter(r_id=rests)
        for i in order:
            s = i.order.all()
            for j in s:
                print(j.item.name)
                set_key(orderdict,i,j)
        print(orderdict)
        return render(request,'trial.html',{'res':rest,'order':orderdict})

@csrf_exempt
def tt(request):
    if request.method == 'POST':

        l=[]
        itemname=[]
        itemprice=[]
        itemqty=[]
        detail = {}
        orderdetail={}
        oid = request.POST.get("oid")
        print(oid)
        vis = OrderTrack.objects.filter(id=oid).values()
        user = OrderTrack.objects.get(id=oid)
        address = user.delivery_addr.address
        landmark = user.delivery_addr.landmark
        rname = user.r_id.rname
        area = user.r_id.area

        vk  = user.order.all()
        print(vk)
        for i in vk:
            itemqty.append(i.qty)
            itemname.append(i.item.name)
            itemprice.append(i.item.price)
        orderdetail['rname']=rname
        orderdetail['area']=area
        orderdetail['itemname']=itemname
        orderdetail['itemprice']=itemprice
        orderdetail['qty']=itemqty
        orderdetail['address']=address
        orderdetail['landmark']=landmark
        l.append(orderdetail)
        # print(itemqty,rname,area,itemname,itemprice)
        return JsonResponse({'user':list(vis),'order':list(l)})
    else:
        return JsonResponse({'status':1})

@csrf_exempt
def Favourite(request):
    if request.method == 'POST':
        users = request.session.get('customer')
        user = Customer.objects.get(id=users)
        resid = request.POST.get("resid")
        res = Restaurant.objects.get(id=resid)

        print(res.favourite.all())
        if user in res.favourite.all():
            res.favourite.remove(user)

            return JsonResponse({'status':0})
        else:
            res.favourite.add(user)
            return JsonResponse({'status':1})

@csrf_exempt
def metrics(request):
    if request.method == 'POST':
        rid = request.POST.get('rid')

        data=[]
        Order = OrderTrack.objects.filter(r_id=rid)
        print('order:',Order)
        di = {}
        for i in Order:
            vk = i.abc(i)
            set_key(di,vk,i.total_amount)
        for l,v in di.items():
            if isinstance(v,list):
                vk = sum(v)
                di[l]=vk
            else:
                pass
        data.append(di)

        return JsonResponse({'dataset':data})

def set_key(dictionary, key, value):
    if key not in dictionary:
        dictionary[key] = value
    elif type(dictionary[key]) == dict:
        dictionary[key].append(value)
    else:
        dictionary[key] = [dictionary[key], value]

@csrf_exempt
def editadd(request):
    if request.method == 'POST':
        adid = request.POST.get('addid')
        addres = CustomerAddress.objects.get(id=adid)
        dic = [{'id':addres.id,'name':addres.name,'address':addres.address,'landmark':addres.landmark,'pincode':addres.pincode,'city':addres.city,'state':addres.state}]
        return JsonResponse({'status':dic})

@csrf_exempt
def deleteadd(request):
    if request.method == 'POST':
        adid = request.POST.get('addid')
        addres = CustomerAddress.objects.get(id=adid)
        addres.delete()
        print(addres)
        return JsonResponse({'status':adid})

@csrf_exempt
def editcat(request):
    if request.method=='POST':
        print("call")
        adids = request.POST.get('editcatid')
        catname = request.POST.get('catname')
        print(adids,catname)
        Catagory.objects.filter(id=adids).update(name=catname)
        return JsonResponse({'status':adids})

def logout(request):
    request.session['restaurant']={}
    return  redirect('res_login')

def userlogout(request):
    del request.session['customer']
    return  redirect('index')

@csrf_exempt
def editnumber(request):
    if request.method == 'POST':
        votp = request.POST.get('otp')
        num = request.POST.get('num')
        otp = request.session.get('otp')
        userid = request.session.get('customer')
        user = Customer.objects.get(id=userid)
        if otp == int(votp):
            print("number change loop")
            Customer.objects.filter(id=user.id).update(phone_number=num)
            return JsonResponse({'status':'number change successfully'})
        else:
            return JsonResponse({'status':'wrong otp'})
@csrf_exempt
def editemail(request):
    if request.method=="POST":
        email = request.POST.get('email')
        userid = request.session.get('customer')
        user = Customer.objects.get(id=userid)
        if email:
            Customer.objects.filter(id=user.id).update(email=email)
            return JsonResponse({'status':'email change successfully!'})
        else:
            return JsonResponse({'status':'something went wrong!'})

