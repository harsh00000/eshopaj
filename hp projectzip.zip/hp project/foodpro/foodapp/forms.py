from django import forms
from .models import *

class menu(forms.ModelForm):
    class Meta:
        model=Menuitem
        fields=['name','image','veg','description','price']

class im(forms.Form):
    image = forms.ImageField()