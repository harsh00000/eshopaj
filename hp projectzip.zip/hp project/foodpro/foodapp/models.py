from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from asgiref.sync import async_to_sync
import json
from channels.layers import get_channel_layer
import random , string

# Create your models here.


class Customer(models.Model):
    name = models.CharField(max_length=20)
    phone_number = models.CharField(max_length=10)
    email = models.EmailField()

class Resuser(models.Model):
    phone = models.CharField(max_length=10)
    email = models.EmailField()
    password = models.CharField(max_length=100)

class Restaurant(models.Model):
    resuser         = models.OneToOneField(Resuser,on_delete=models.CASCADE)
    favourite       = models.ManyToManyField(Customer,blank=True)
    rname 		    = models.CharField(max_length=100,blank=False)
    owner_name 		= models.CharField(max_length=100,blank=False)
    owner_phone		= models.CharField(max_length=10,blank=False)
    address         = models.CharField(max_length=40, blank=False)
    area            = models.CharField(max_length=10)
    city            = models.CharField(max_length=20)
    state           = models.CharField(max_length=20)
    r_logo          = models.ImageField(upload_to='media')
    cost_for_two    = models.PositiveIntegerField(default=100)
    deliverytime    = models.CharField(max_length=3)
    REST_STATE_OPEN = "Open"
    REST_STATE_CLOSE= "Closed"

    REST_STATE_CHOICES = (
        (REST_STATE_OPEN, REST_STATE_OPEN),
        (REST_STATE_CLOSE, REST_STATE_CLOSE)
    )
    status = models.CharField(max_length=50, choices=REST_STATE_CHOICES, default=REST_STATE_OPEN, blank=False)
    approved = models.BooleanField(blank=False, default=False)


    def __str__(self):
        return self.rname

class Catagory(models.Model):
    name = models.CharField(max_length=50)
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE)
    available = models.BooleanField(default=True)
    def __str__(self):
        return self.name

class Menuitem(models.Model):
    catagory = models.ForeignKey(Catagory,on_delete=models.CASCADE)
    name  = models.CharField(max_length=50)
    image = models.ImageField(upload_to='media',blank=True)
    veg = models.BooleanField(default=True)
    description = models.CharField(max_length=50,blank=True)
    price = models.PositiveIntegerField(blank=False , default=100)
    available = models.BooleanField(default=True)

    @staticmethod
    def get_item(ids):
        return Menuitem.objects.filter(id__in=ids)

class CustomerAddress(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    name = models.CharField(max_length=20)
    address = models.CharField(max_length=300)
    landmark = models.CharField(max_length=100)
    pincode = models.CharField(max_length=7)
    city = models.CharField(max_length=30)
    state = models.CharField(max_length=30)


# def random_string_generator(size=10, chars=string.ascii_lowercase + string.digits):
#     return ''.join(random.choice(chars) for _ in range(size))

class OrderdItem(models.Model):
    item = models.ForeignKey(Menuitem,on_delete=models.CASCADE)
    qty  = models.PositiveIntegerField()


    def place_order(self):
        self.save()


def random_string_generator(size=10, chars=string.ascii_lowercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))

class OrderTrack(models.Model):
    order           = models.ManyToManyField(OrderdItem)
    r_id            = models.ForeignKey(Restaurant ,on_delete=models.CASCADE)
    orderedBy       = models.ForeignKey(Customer ,on_delete=models.CASCADE)
    delivery_addr   = models.ForeignKey(CustomerAddress,on_delete=models.CASCADE,)
    order_id        = models.CharField(max_length=100 , blank=True)
    total_amount    = models.FloatField(default=0)
    timestamp       = models.DateTimeField(auto_now_add=True)

    CHOICES = (
        ("Order Recieved", "Order Recieved"),
        ("Baking", "Baking"),
        ("Baked", "Baked"),
        ("Out for delivery", "Out for delivery"),
        ("Order Delivered", "Order Delivered"),

    )

    status = models.CharField(max_length=50,choices=CHOICES,default="Order Recieved")
    payment = models.BooleanField(default=False)
    orderconfirm = models.BooleanField(null=True)

    def save(self, *args, **kwargs):
        if not len(self.order_id):
            self.order_id = random_string_generator()
        super(OrderTrack, self).save(*args, **kwargs)

    def __str__(self):
        return str(self.id)


    @staticmethod
    def abc(self):
        return  self.timestamp.strftime("%b-%y")

    @staticmethod
    def give_order_details(order_id):
        instance = OrderTrack.objects.filter(order_id=order_id).first()
        data  = {}
        data['order_id'] = instance.order_id
        data['total_amount'] = instance.total_amount
        data['status'] = instance.status
        data['timestamp'] = str(instance.timestamp)
        progress_percentage = 20
        if instance.status == 'Order Recieved':
            progress_percentage = 20
        elif instance.status == 'Baking':
            progress_percentage = 40
        elif instance.status == 'Baked':
            progress_percentage = 60
        elif instance.status == 'Out for delivery':
            progress_percentage = 80
        elif instance.status == 'Order Delivered':
            progress_percentage = 100

        data['progress'] = progress_percentage

        return data
@receiver(post_save, sender=OrderTrack)
def order_status_handler(sender, instance,created , **kwargs):

    if not created:
        print("###################")
        channel_layer = get_channel_layer()
        data  = {}
        data['order_id'] = instance.order_id
        data['total_amount'] = instance.total_amount
        data['status'] = instance.status
        data['timestamp'] = str(instance.timestamp)
        progress_percentage = 20
        if instance.status == 'Order Recieved':
            progress_percentage = 20
        elif instance.status == 'Baking':
            progress_percentage = 40
        elif instance.status == 'Baked':
            progress_percentage = 60
        elif instance.status == 'Out for delivery':
            progress_percentage = 80
        elif instance.status == 'Order Delivered':
            progress_percentage = 100


        data['progress'] = progress_percentage
        async_to_sync(channel_layer.group_send)(
            'order_%s' % instance.order_id,{
                'type': 'order_status',
                'value': json.dumps(data)
            }
        )


class Transection(models.Model):
    order_id = models.ForeignKey(OrderTrack, on_delete=models.CASCADE)
    TXNID = models.CharField(max_length=50)
    TXNAMOUNT = models.IntegerField(default=0)
    PAYMENTMODE =models.CharField(max_length=100)
    TXNDATE = models.DateTimeField()

