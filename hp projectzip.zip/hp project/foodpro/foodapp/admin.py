from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Customer)
admin.site.register(Restaurant)
admin.site.register(Menuitem)
admin.site.register(CustomerAddress)
admin.site.register(OrderdItem)
admin.site.register(Transection)
admin.site.register(Resuser)



@admin.register(OrderTrack)
class Order(admin.ModelAdmin):
    list_display = ('id', 'status')
    readonly_fields = ('timestamp',)

@admin.register(Catagory)
class Order(admin.ModelAdmin):
    list_display = ('id', 'restaurant')

