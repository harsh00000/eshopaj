// scroll effect

   var lastscrolltop = 399;
 	var num =400
 	$(window).scroll(function(event){
 		var st = $(this).scrollTop();
 		if(st < lastscrolltop){
 			$('.menu1').slideDown(150);
      //$('body').css('background-color','white');
 		} else{
 			$('.menu1').slideUp(150);
      //$('body').css('background-color','#37718e');
 		}
 	});
 	$(window).bind('scroll', function () {

 	if ($(window).scrollTop() > num) {
        $('.menu').addClass('fixed');

    } else {
        $('.menu').removeClass('fixed');


    }
});

// div hide and show
      $(document).ready(function(){
       
       $('.overla1').hide();
       $('.box1').hide();

       $('.box').show();
      $(".overla2").hide();
      $('.frm').hide();
      $('.bn1').hide();
      $('.otp').hide();
      $('.sn').hide();
       $('.sn1').hide();
        $('.eot').hide();
      $('.overla').hide();


        $('.work').on('click', function(){

              $('#fade-in').addClass('show');
              $('.overla').show();
              $("body").addClass("modal-open");
              });
        $('.cbtn').on('click', function(){
              $('#fade-in').removeClass('show');
              $("body").removeClass("modal-open");
              $('.overla').hide();



    });




      $('.signin').on('click', function(){
      $('#fade-inon').addClass('show');
      $('.overla1').show();
      $("body").addClass("modal-open");
        $('.cbtn1').on('click', function(){
      $('#fade-inon').removeClass('show');
      $("body").removeClass("modal-open");
      $('.overla1').hide();
    });
    });





          






        $(".sign").on("click", function () {
          $("#fade-inin").addClass("show");
          $(".overla2").show();
          $("body").addClass("modal-open");
          $(".cbtn2").on("click", function () {
            $("#fade-inin").removeClass("show");
            $("body").removeClass("modal-open");
            $(".overla2").hide();
          });
        });






        $('.bn').click(function(){
          $('.otp').show();
        });

        $('.act').click(function(){
          $('.fm').toggle();
          $('.bn').hide();
          $('.sn').show();
          $('.ln').hide();
          $('.or').hide();
          $('.frm').show();
          $('.sn1').show();
           $('.bn1').show();
        });
        $('.lac').click(function(){
              $('.ln').show();
              $('.or').show();
              $('.fm').toggle();
              $('.sn').hide();
              $('.frm').hide();
              $('.bn1').hide();
              $('.sn1').hide();
              $('.otp').hide();
              $('.bn').show();

        });
        $('.oottpp').click(function(){
          $('.eot').show();
        });


        
        

// form submit

        $("#c_s_submit").click(function(){
              let url ="/UserCreate/"
              let wurl ="/"
           		let MobNumber = $("#phone_number").val();
              let name = $("#name").val()
              let email = $("#email").val()
              let otp = $("#otp").val()
              let csr = $("input[name=csrfmiddlewaretoken]").val();
              mydata={phone:MobNumber,name:name,email:email,otp:otp,csrfmiddlewaretoken:csr}
           		$.ajax({
          url:url,
          method:'POST',
          data:mydata,
          success:function(data){
            console.log(data.status);
            window.location.href = "/";
          },
        })
           });

// otp send 
    $("#send_otp").click(function(){
    alert('click');
    let url ="/SendOtp/"
      let MobNumber = $("#phone_number").val();
      let csr = $("input[name=csrfmiddlewaretoken]").val();
       mydata = {MobNumber:MobNumber,csrfmiddlewaretoken:csr};
      $.ajax({
          url:url,
          method:'POST',
          data:mydata,
          success:function(data){
            console.log(data.status);
          },
        })
   });
    
    //customer login
     $("#c_l_submit").click(function(){
              url = "/UserLogin/"
              let MobNumber = $("#phone").val();
              let lotp = $("#lotp").val();
              
              let csr = $("input[name=csrfmiddlewaretoken]").val();
              mydata = {phone:MobNumber,otp:lotp,csrfmiddlewaretoken:csr};
              $.ajax({
          url:url,
          method:'POST',
          data:mydata,
          success:function(data){
            console.log(data.status);
            window.location.href = "/";
          },
        })
            });

     
 }); // ready event closing
