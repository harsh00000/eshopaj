"""foodpro URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from foodapp import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('UserCreate/', views.UserCreate, name='UserCreate'),
    path('UserLogin/', views.UserLogin, name='UserLogin'),
    path('SendOtp/',views.SendOtp,name='SendOtp'),
    path('search/',views.search,name='search'),
    path('favourite/',views.Favourite,name='favourite'),
    path('userprofile/', views.userprofile, name='userprofile'),
    path('checkout/', views.checkout, name='checkout'),
    path('address/', views.address, name='address'),
    path('restaurant/<int:id>/', views.Resturant, name='resturant'),
    path('restaurant/login/', views.res_login, name='res_login'),
    path('restaurant/profile/', views.res_profile, name='res_profile'),
    path('admin/home/', views.adminhome, name='adminhome'),
    path('changes/',views.changes,name="changes"),
    path('catavilable/',views.catavilable,name="catavilable"),
    path('itemavilable/',views.itemavilable,name="itemavilable"),
    path('avchanges/',views.avchanges,name="avchanges"),
    path('statuschanges/',views.statuschanges,name="statuschanges"),
    path('itemchanges/',views.itemchanges,name="itemchanges"),
    path('itemdelete/',views.itemdelete,name="itemdelete"),
    path('handlerequest/', views.handlerequest, name='HandleRequest'),
    path('track/<order_id>/', views.track, name='track'),
    path('metrics/', views.metrics, name='metrics'),
    path('trial/', views.trial, name='trial'),
    path('tt/', views.tt, name='tt'),
    path('editadd/', views.editadd, name='editadd'),
    path('deleteadd/', views.deleteadd, name='deleteadd'),
    path('editcat/', views.editcat, name='editcat'),
    path('logout/', views.logout, name='logout'),
    path('userlogout/', views.userlogout, name='userlogout'),
    path('editnumber/', views.editnumber, name='editnumber'),
    path('editemail/', views.editemail, name='editemail'),





] +static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
